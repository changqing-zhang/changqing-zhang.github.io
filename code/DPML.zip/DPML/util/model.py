import tensorflow as tf
import numpy as np
from util.util_adni import xavier_init


class CPMNets():
    """build model
    """
    def __init__(self, view_num, trainLen, testLen,layer_size,layer_size_d, lsd_dim=128, learning_rate=[0.001, 0.001], lamb=1,lamb_gen=100): #deleted

        """
        :param learning_rate:learning rate of network and h
        :param view_num:view number
        :param layer_size:node of each net
        :param layer_size_d:node of each D net
        :param lsd_dim:latent space dimensionality
        :param trainLen:training dataset samples
        :param testLen:testing dataset samples
        """
        # initialize parameter
        self.view_num = view_num
        self.layer_size = layer_size
        self.layer_size_d = layer_size_d
        self.lsd_dim = lsd_dim
        self.trainLen = trainLen
        self.testLen = testLen
        self.lamb = lamb
        self.lamb_gen = lamb_gen
        # initialize latent space data
        self.h_train, self.h_train_update = self.H_init('train')
        self.h_test, self.h_test_update = self.H_init('test')
        self.h = tf.concat([self.h_train, self.h_test], axis=0)
        self.h_index = tf.placeholder(tf.int32, shape=[None, 1], name='h_index')
        self.h_temp = tf.gather_nd(self.h, self.h_index)
        # initialize the input data
        self.input = dict()
        self.sn = dict()
        self.sn_reverse = dict()
        self.net = dict()
        for v_num in range(self.view_num):
            self.input[str(v_num)] = tf.placeholder(tf.float32, shape=[None, self.layer_size[v_num][-1]],
                                                    name='input' + str(v_num))
            self.sn[str(v_num)] = tf.placeholder(tf.float32, shape=[None, 1], name='sn' + str(v_num))
            self.sn_reverse[str(v_num)] = tf.placeholder(tf.float32, shape=[None, 1], name='sn_reverse' + str(v_num))
        # ground truth
        self.gt = tf.placeholder(tf.int32, shape=[None], name='gt')
        # bulid the model
        self.train_op, self.loss = self.bulid_model([self.h_train_update, self.h_test_update], learning_rate)
        # open session
        gpu_options = tf.GPUOptions(allow_growth=True)
        self.sess = tf.Session(config=tf.ConfigProto(gpu_options=gpu_options))
        self.sess.run(tf.global_variables_initializer())
        self.saver = tf.train.Saver()

    def bulid_model(self, h_update, learning_rate):
        # initialize network
        r_logits = dict()
        f_logits = dict()
        r_rep = dict()
        g_rep = dict()
        self.samples = dict()
        for v_num in range(self.view_num):
            self.net[str(v_num)] = self.Encoding_net(self.h_temp, v_num)

            r_logits[str(v_num)], r_rep[str(v_num)] = self.Discriminating_net(self.input[str(v_num)],v_num) #real sample
            f_logits[str(v_num)], g_rep[str(v_num)] = self.Discriminating_net(self.net[str(v_num)],v_num, reuse=True) #generated sample
        tf.add_to_collection('pred_network', self.net)
        # calculate reconstruction loss
        reco_loss = self.reconstruction_loss(self.net)
        # calculate gan loss
        disc_loss = self.discriminator_loss(r_logits,f_logits)
        gen_loss = self.generator_loss(f_logits)
        g_loss = tf.add(self.lamb_gen *gen_loss,reco_loss)
        all_loss = tf.add(reco_loss, self.lamb * disc_loss)
        # train net operator
        # train the discriminator to minimize disc_loss
        train_dis_op = tf.train.AdamOptimizer(learning_rate[2]) \
            .minimize(disc_loss, var_list=tf.get_collection('weight_d'))
        # train the network to minimize reconstruction loss(generator)
        train_net_op = tf.train.AdamOptimizer(learning_rate[0]) \
            .minimize(g_loss, var_list=tf.get_collection('weight'))
        # train the latent space data to minimize reconstruction loss and classification loss
        train_hn_op = tf.train.AdamOptimizer(learning_rate[1]) \
            .minimize(all_loss, var_list=h_update[0]) #?
        # adjust the latent space data
        adj_hn_op = tf.train.AdamOptimizer(learning_rate[0]) \
            .minimize(all_loss, var_list=h_update[1])
        return [train_dis_op,train_net_op, train_hn_op, adj_hn_op], [reco_loss,disc_loss, gen_loss,g_loss, all_loss]

    def H_init(self, a):
        with tf.variable_scope('H' + a):
            if a == 'train':
                h = tf.Variable(xavier_init(self.trainLen, self.lsd_dim))
            elif a == 'test':
                h = tf.Variable(xavier_init(self.testLen, self.lsd_dim))
            h_update = tf.trainable_variables(scope='H' + a)
        return h, h_update

    def Encoding_net(self, h, v):
        weight = self.initialize_weight(self.layer_size[v])
        layer = tf.matmul(h, weight['w0']) + weight['b0']
        for num in range(1, len(self.layer_size[v])):
            layer = tf.nn.dropout(tf.matmul(layer, weight['w' + str(num)]) + weight['b' + str(num)], 0.9)
        return layer



    def Discriminating_net(self, h, v,reuse=False):
        with tf.variable_scope("Discriminator", reuse=reuse):
            weight_d = self.initialize_weight_d(self.layer_size_d[v],v)
            layer = tf.matmul(h, weight_d['w0']) + weight_d['b0']
            for num in range(1, len(self.layer_size_d[v])):
                layer = tf.nn.dropout(tf.matmul(layer, weight_d['w' + str(num)]) + weight_d['b' + str(num)], 0.9)
            layer = layer
            output = tf.sigmoid(layer)
            return layer,output

    def initialize_weight(self, dims_net):
        all_weight = dict()
        with tf.variable_scope('weight'):
            all_weight['w0'] = tf.Variable(xavier_init(self.lsd_dim, dims_net[0]))
            all_weight['b0'] = tf.Variable(tf.zeros([dims_net[0]]))
            tf.add_to_collection("weight", all_weight['w' + str(0)])
            tf.add_to_collection("weight", all_weight['b' + str(0)])
            for num in range(1, len(dims_net)):
                all_weight['w' + str(num)] = tf.Variable(xavier_init(dims_net[num - 1], dims_net[num]))
                all_weight['b' + str(num)] = tf.Variable(tf.zeros([dims_net[num]]))
                tf.add_to_collection("weight", all_weight['w' + str(num)])
                tf.add_to_collection("weight", all_weight['b' + str(num)])
        return all_weight

    def initialize_weight_d(self, dims_net,v):
        all_weight_d = dict()
        lsd_dim = self.input[str(v)].shape[1].value
        with tf.variable_scope('weight_d'):
            all_weight_d['w0'] = tf.Variable(xavier_init(lsd_dim, dims_net[0]))
            all_weight_d['b0'] = tf.Variable(tf.zeros([dims_net[0]]))
            tf.add_to_collection("weight_d", all_weight_d['w' + str(0)])
            tf.add_to_collection("weight_d", all_weight_d['b' + str(0)])
            for num in range(1, len(dims_net)):
                all_weight_d['w' + str(num)] = tf.Variable(xavier_init(dims_net[num - 1], dims_net[num]))
                all_weight_d['b' + str(num)] = tf.Variable(tf.zeros([dims_net[num]]))
                tf.add_to_collection("weight_d", all_weight_d['w' + str(num)])
                tf.add_to_collection("weight_d", all_weight_d['b' + str(num)])
        return all_weight_d

    def reconstruction_loss(self, net):
        loss = 0
        for num in range(self.view_num):
            loss = loss + tf.reduce_sum(
                tf.pow(tf.subtract(net[str(num)], self.input[str(num)])
                       , 2.0) * self.sn[str(num)]
            )
        return loss

    def discriminator_loss(self, r_logits,f_logits):
        loss = 0
        for num in range(self.view_num):
            loss = loss + tf.reduce_mean((
                tf.nn.sigmoid_cross_entropy_with_logits(
                    logits=r_logits[str(num)], labels=tf.ones_like(
            r_logits[str(num)])) + tf.nn.sigmoid_cross_entropy_with_logits(
                    logits=f_logits[str(num)], labels=tf.zeros_like(f_logits[str(num)]))
            ) * self.sn_reverse[str(num)]
            )
        return loss

    def generator_loss(self,f_logits):
        loss = 0
        for num in range(self.view_num):
            loss = loss + tf.reduce_mean(
                tf.nn.sigmoid_cross_entropy_with_logits(
                logits=f_logits[str(num)], labels=tf.ones_like(f_logits[str(num)])) * self.sn_reverse[str(num)]
            )
        return loss

    def classification_loss(self):
        F_h_h = tf.matmul(self.h_temp, tf.transpose(self.h_temp))
        F_hn_hn = tf.diag_part(F_h_h)
        F_h_h = tf.subtract(F_h_h, tf.matrix_diag(F_hn_hn))
        classes = tf.reduce_max(self.gt) - tf.reduce_min(self.gt) + 1
        label_onehot = tf.one_hot(self.gt - 1, classes)  # gt begin from 1
        label_num = tf.reduce_sum(label_onehot, 0, keep_dims=True)  # should sub 1.Avoid numerical errors
        F_h_h_sum = tf.matmul(F_h_h, label_onehot)
        label_num_broadcast = tf.tile(label_num, [self.trainLen, 1]) - label_onehot
        F_h_h_mean = tf.divide(F_h_h_sum, label_num_broadcast)
        gt_ = tf.cast(tf.argmax(F_h_h_mean, axis=1), tf.int32) + 1  # gt begin from 1
        F_h_h_mean_max = tf.reduce_max(F_h_h_mean, axis=1, keep_dims=False)
        theta = tf.cast(tf.not_equal(self.gt, gt_), tf.float32)
        F_h_hn_mean_ = tf.multiply(F_h_h_mean, label_onehot)
        F_h_hn_mean = tf.reduce_sum(F_h_hn_mean_, axis=1, name='F_h_hn_mean')
        return tf.reduce_sum(tf.nn.relu(tf.add(theta, tf.subtract(F_h_h_mean_max, F_h_hn_mean))))


    def train(self, data, sn, sn_reverse,gt, epoch, step=[10, 10, 10]):
        global Reconstruction_LOSS
        index = np.array([x for x in range(self.trainLen)])
        gt = gt[index]
        sn = sn[index]
        sn_reverse = sn_reverse[index]

        feed_dict = {self.input[str(v_num)]: data[str(v_num)][index] for v_num in range(self.view_num)}
        feed_dict.update({self.sn[str(i)]: sn[:, i].reshape(self.trainLen, 1) for i in range(self.view_num)})
        feed_dict.update({self.sn_reverse[str(i)]: sn_reverse[:, i].reshape(self.trainLen, 1) for i in range(self.view_num)})
        feed_dict.update({self.gt: gt})
        feed_dict.update({self.h_index: index.reshape((self.trainLen, 1))})
        for iter in range(epoch):
            # update the network d
            for i in range(step[0]):
                _,Discriminator_LOSS, All_loss = self.sess.run(
                    [self.train_op[0], self.loss[1],self.loss[4]], feed_dict=feed_dict)
            # update the network g
            for i in range(step[1]):
                _,Reconstruction_LOSS, Gen_LOSS, G_LOSS, All_loss = self.sess.run(
                    [self.train_op[1], self.loss[0],self.loss[2],self.loss[3],self.loss[4]], feed_dict=feed_dict)
            # update the h
            for i in range(step[2]):
                _, Reconstruction_LOSS, Discriminator_LOSS, Gen_LOSS, G_LOSS, All_loss = self.sess.run(
                    [self.train_op[2], self.loss[0], self.loss[1], self.loss[2], self.loss[3], self.loss[4]], feed_dict=feed_dict)
            output = "Epoch : {:.0f}  ===> recon = {:.4f}, g = {:.4f}, all = {:.4f}" \
               .format((iter + 1), Reconstruction_LOSS, G_LOSS, All_loss)
            print(output)

    def test(self):
        lsd = self.get_h_train()
        feed_dict = {self.h_temp: lsd}
        feed_dict.update({self.h_index: np.array([x for x in range(self.trainLen)]).reshape(self.trainLen, 1)}) # +self.trainLen
        result = self.sess.run(self.net,feed_dict=feed_dict)
        return result


    def get_h_train(self):
        lsd = self.sess.run(self.h)
        return lsd[0:self.trainLen]
