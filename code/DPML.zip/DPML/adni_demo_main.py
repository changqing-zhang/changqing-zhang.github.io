import numpy as np
import scipy.io as sio
from util.util_adni import read_data
from util.get_sn import get_sn_reverse
from util.model import CPMNets
import tensorflow as tf
from skimage.measure import compare_nrmse
from util.cluster_matric import cluster
from sklearn import metrics
from sklearn.cluster import KMeans
import os
import warnings
warnings.filterwarnings("ignore")
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--lsd-dim', type=int, default=50,
                        help='dimensionality of the latent space data [default: 50]')
    parser.add_argument('--epochs-train', type=int, default=30 , metavar='N',
                        help='number of epochs to train [default: 30]')
    parser.add_argument('--epochs-test', type=int, default=300, metavar='N',
                        help='number of epochs to test [default: 60]')
    parser.add_argument('--lamb', type=float, default=1, #1
                        help='trade off parameter [default: 1]')
    parser.add_argument('--lamb_gen', type=float, default=1,
                        help='trade off parameter [default: 1]')
    parser.add_argument('--missing-rate', type=float, default=0,
                        help='view missing rate [default: 0]')
    args = parser.parse_args()
    args.lsd_dim =[10]
    args.lamb=[1]
    args.missing_rate =[0]
    net_dim=[128]
    for rate in args.missing_rate:
        print("missing rate:",rate)
        for dim in args.lsd_dim:
            print("dim:", dim)
            for lam in args.lamb:
                print("lamb",lam)
                for netdim in net_dim:
                    print("netdim", netdim)
                    for k in range(20):
                        print("k",k)
                        # read data
                        trainData,  view_num = read_data('./data/ADNI_3classes.mat', 1, 0)

                        outdim_size = [trainData.data[str(i)].shape[1] for i in range(view_num)]
                        # set layer size
                        layer_size = [[128, outdim_size[i]] for i in range(view_num)]
                        layer_size_d = [[netdim, outdim_size[i]] for i in range(view_num)]
                        # set parameter
                        epoch = [args.epochs_train, args.epochs_test]
                        learning_rate = [0.01, 0.01, 0.01]

                        data = sio.loadmat('./data/ADNI_sn.mat')
                        Sn = data['Sn']
                        Sn_reverse = get_sn_reverse(Sn)
                        Sn_train = Sn[np.arange(trainData.num_examples)]
                        Sn_train_reverse = get_sn_reverse(Sn_train)

                        # Model building
                        model = CPMNets(view_num, trainData.num_examples,0,
                                        layer_size,
                                        layer_size_d,
                                        lsd_dim=dim,
                                        learning_rate=learning_rate,
                                        lamb=lam,
                                        lamb_gen=args.lamb_gen)


                        model.train(trainData.data,Sn_train,Sn_train_reverse,
                                    trainData.labels.reshape(trainData.num_examples), epoch[0], step=[10, 10, 10])
                        H_train = model.get_h_train()


                        # compute clustering performance
                        print("ours")
                        cluster(data='adni', missingrate=rate, method='our', n_clusters=3, features=H_train,
                                labels=trainData.labels, count=10,
                                rt=False)
                        generation = model.test()  #generated result including complete view
                        our_array = np.zeros(view_num)

                        for v_num in range(view_num):
                            Sn_tile_train = np.transpose(np.tile(Sn_train[:, v_num], (trainData.data[str(v_num)].shape[1], 1)))
                            Sn_tile_train_reverse =get_sn_reverse(Sn_tile_train)
                            our_nrmse_min = compare_nrmse(Sn_tile_train_reverse * trainData.data[str(v_num)],
                                                      Sn_tile_train_reverse * generation[str(v_num)], norm_type='min-max')
                            if v_num == view_num-1 :
                                kmeans_our = KMeans(n_clusters=3, random_state=0).fit(H_train)
                                result_NMI_our = metrics.normalized_mutual_info_score(kmeans_our.labels_, trainData.labels.transpose()[0])
                                print("our=",result_NMI_our)
                            our_mse = tf.reduce_mean(Sn_tile_train_reverse * tf.square(generation[str(v_num)] - trainData.data[str(v_num)]))


