import utils
from gLMSC import GeneralLMSC, GeneralLMSCModel, GeneralLMSCTrainer
import numpy as np
import torch
import scipy.io as sio
import time
from tqdm import tqdm
from torch import cuda
import matplotlib.pyplot as plt
import sys
import random

cuda_idx = 0
cuda.set_device(cuda_idx)
seed = 100

random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)


traindata, testdata, view_number = utils.read_matlab_data('../dataset/yale_mtv.mat', ratio=1.0, shuffled=False, Normal=2)
# H_orign = sio.loadmat('./Yale_H_orignal.mat')['H'].astype(np.float64)
if len(sys.argv) != 2:
    path = './gLMSC_tanh_iter500_EPOCH700_model.pkl'
else:
    path = sys.argv[1]
    print('path:', path)

# g_LMSC_model = GeneralLMSC(
#     labels=traindata.labels, 
#     class_num=len(np.unique(traindata.labels)), 
#     Lambda=0.1,
#     K=200,
#     max_iter=100
# )

# t1 = time.time()
# Z, H, converge_flag, iteration, conv = g_LMSC_model.train(traindata, H_orign)
# t2 = time.time()
# print('converge: {}, total {} iterations, cost {:.2f} s of time, converge value: {:.8f}'.format(converge_flag, iteration, t2 - t1, conv))

trainer = GeneralLMSCTrainer(
    traindata, 
    Lambda=1, 
    K=100,
    lrW=0.005, 
    lrH=0.01,
    lrZ=0.01,
    # H_orign=H_orign,
    grad_Z=True,
    gamma=1e-3,
    separate_updated=True,
    max_iter=200
)

EPOCH = 30

convs = np.zeros(EPOCH)
Hloss = np.zeros(EPOCH)
Wloss = np.zeros(EPOCH)
Zloss = np.zeros(EPOCH)
F = np.zeros(EPOCH)
NMI = np.zeros(EPOCH)
ACC = np.zeros(EPOCH)
RI = np.zeros(EPOCH)
# loss = np.zeros(EPOCH)

best = 1e10
t = 0.0
for i in tqdm(range(EPOCH), total=EPOCH,):
    # convs[i], Wloss[i], Hloss[i] = trainer.train_a_epoch()
    # convs[i], loss[i] = trainer.train_a_epoch()
    t1 = time.time()
    Wloss[i], Hloss[i], Zloss[i] = trainer.train_a_epoch()
    t2 = time.time()
    t += (t2 - t1)
    # print('epoch eval : converge value: {:.6f}, Wloss: {:.6f}, Hloss: {:.6f}'.format(convs[i], Wloss[i], Hloss[i]))
    # print('epoch eval : converge value: {:.6f}, loss: {:.6f}'.format(convs[i], loss[i]))
    print('epoch eval : Wloss: {:.6f}, Hloss: {:.6f}, Zloss: {:.6f}'.format(Wloss[i], Hloss[i], Zloss[i]))
    Z, H = trainer.get_affine_mat()

    cluster_model = utils.Clustering(len(np.unique(traindata.labels)))
    pred_labels = cluster_model.clustering(torch.abs(Z) + torch.abs(Z.T), traindata.labels)

    nmi = cluster_model.calc_nmi(traindata.labels, pred_labels)
    f, p, r = cluster_model.calc_f(traindata.labels, pred_labels)
    acc = cluster_model.calc_acc(traindata.labels, pred_labels)
    ar, ri, mi, hi = cluster_model.calc_rand_index(traindata.labels, pred_labels, adjusted=False)
    F[i] = f
    NMI[i] = nmi
    ACC[i] = acc
    RI[i] = ri

    # print(nmi, f, p, r, acc, ri)
    print('nmi: {:.3f}, f: {:.3f}, p: {:.3f}, r: {:.3f}, acc: {:.3f}\n AR: {:.3f}, RI: {:.3f}, MI: {:.3f}, HI: {:.3f}'.format(nmi, f, p, r, acc, ar, ri, mi, hi))


    # total_loss = (convs[i] + loss[i]) / 2.0
    # total_loss = (Wloss[i] + Hloss[i] + Zloss[i]) / 3.0
    total_eval = (f + nmi + acc + ri) / 4.0
    if total_eval < best:
        best = total_eval
        trainer.save(path)


# # LOSSES = [convs, Hloss, Wloss]
# # str_losses = ['converge value', 'H loss', 'W loss']

# # for loss, str_loss in zip(LOSSES, str_losses):
# #     plt.figure(figsize=(12, 8))
# #     plt.plot(range(EPOCH), convs, 'b-')
# #     plt.title('{} while training'.format(str_loss))
# #     plt.xlabel('EPOCH')
# #     plt.ylim((0.0, 1.0))
# #     plt.savefig('./{}.png'.format(str_loss), dpi=500)
# #     # plt.show()

# # LOSSES = [convs, loss]
# # str_losses = ['converge value', 'loss']
LOSSES = [Wloss, Hloss, Zloss, NMI, F, ACC, RI]
str_losses = ['W loss', 'H loss', 'Z loss', 'NMI', 'F', 'ACC', 'RI']

for loss, str_loss in zip(LOSSES, str_losses):
    plt.figure(figsize=(12, 8))
    plt.plot(range(EPOCH), loss, 'b-')
    plt.title('{} while training'.format(str_loss))
    plt.xlabel('EPOCH')
    plt.ylim((0.0, np.max(loss[-150:]) + 1.0))
    plt.savefig('./{}.png'.format(str_loss), dpi=500)
    # plt.show()

trainer.load(path)
Z, H = trainer.get_affine_mat()

cluster_model = utils.Clustering(len(np.unique(traindata.labels)))
pred_labels = cluster_model.clustering(torch.abs(Z) + torch.abs(Z.T), traindata.labels)

nmi = cluster_model.calc_nmi(traindata.labels, pred_labels)
f, p, r = cluster_model.calc_f(traindata.labels, pred_labels)
acc = cluster_model.calc_acc(traindata.labels, pred_labels)
ar, ri, mi, hi = cluster_model.calc_rand_index(traindata.labels, pred_labels, adjusted=False)

# print(nmi, f, p, r, acc, ri)
print('nmi: {:.3f}, f: {:.3f}, p: {:.3f}, r: {:.3f}, acc: {:.3f}\n AR: {:.3f}, RI: {:.3f}, MI: {:.3f}, HI: {:.3f}'.format(nmi, f, p, r, acc, ar, ri, mi, hi))
print('cost time: {:.4f}s'.format(t))
