import warnings
warnings.filterwarnings('ignore')
import scipy.io as sio
import numpy as np
import math
from numpy.random import shuffle
import torch
from typing import Union, List
from torch import cuda, normal
from sklearn.cluster import SpectralClustering, spectral_clustering
from sklearn.metrics import adjusted_rand_score
# from sklearn.utils.linear_assignment_ import linear_assignment
from scipy.optimize import linear_sum_assignment
from sklearn.metrics.cluster import contingency_matrix
from scipy.special import comb
from sklearn import preprocessing

class DataSet(object):

    def __init__(self, data, view_number, labels):
        """
        Construct a DataSet.
        """
        self.data = dict()
        self.view_cnt = view_number
        self._num_examples = data[0].shape[0]
        self._labels = labels
        for v_num in range(view_number):
            self.data[str(v_num)] = data[v_num]

    @property
    def labels(self):
        return self._labels

    @property
    def num_examples(self):
        return self._num_examples

def Normalize(data):
    """
    :param data:Input data
    :return:normalized data
    """
    m = np.mean(data)
    mx = np.max(data)
    mn = np.min(data)
    return ((data - m) / (mx - mn)).astype(np.float64)

def znormalize(data):
    return preprocessing.scale(data, axis=1)

def matlab_normalize(data:np.ndarray):
    data = data.T
    result = np.sqrt(np.sum(data ** 2, axis=0))
    result = np.repeat(result[None], data.shape[0], axis=0) + np.spacing(1)
    result = data / result
    result = result.T
    return result.astype(np.float64)


def read_matlab_data(mat_path:str, ratio:float, Normal:int=1, shuffled:bool=True):
    """
    read data and spilt it train set and test set evenly
    ---
    :param mat_path:.mat filepath
    :param ratio:training set ratio
    :param Normal:do you want normalize
    ----
    :return:dataset and view number
    """
    data = sio.loadmat(mat_path)
    view_number = data['X'].shape[1]
    X = np.split(data['X'], view_number, axis=1)
    X_train = []
    X_test = []
    labels_train = []
    labels_test = []
    if min(data['gt']) == 0:
        labels = data['gt'] + 1
    else:
        labels = data['gt']
    classes = np.max(labels)
    all_length = 0

    for c_num in range(1, classes + 1):
        c_length = np.sum(labels == c_num)
        index = np.arange(c_length)
        if shuffled:
            shuffle(index)
        
        labels_train.extend(labels[all_length + index][0: math.floor(c_length * ratio)].flatten())
        if ratio < 1.0:
            labels_test.extend(labels[all_length + index][math.floor(c_length * ratio):].flatten())
        X_train_temp = []
        X_test_temp = []
        for v_num in range(view_number):
            X_train_temp.append(X[v_num][0][0].transpose()[all_length + index][0:math.floor(c_length * ratio)])
            if ratio < 1.0:
                X_test_temp.append(X[v_num][0][0].transpose()[all_length + index][math.floor(c_length * ratio):])
        if c_num == 1:
            X_train = X_train_temp
            X_test = X_test_temp
        else:
            for v_num in range(view_number):
                X_train[v_num] = np.r_[X_train[v_num], X_train_temp[v_num]]
                if ratio < 1.0:
                    X_test[v_num] = np.r_[X_test[v_num], X_test_temp[v_num]]
        all_length = all_length + c_length
    if Normal == 1:
        for v_num in range(view_number):
            # X_train[v_num] = Normalize(X_train[v_num])
            X_train[v_num] = matlab_normalize(X_train[v_num])
            if ratio < 1.0:
                # X_test[v_num] = Normalize(X_test[v_num])
                X_test[v_num] = matlab_normalize(X_test[v_num])
    elif Normal == 2:
        for v_num in range(view_number):
            # X_train[v_num] = Normalize(X_train[v_num])
            X_train[v_num] = Normalize(X_train[v_num])
            if ratio < 1.0:
                # X_test[v_num] = Normalize(X_test[v_num])
                X_test[v_num] = Normalize(X_test[v_num])
    elif Normal == 3:
        for v_num in range(view_number):
            # X_train[v_num] = Normalize(X_train[v_num])
            X_train[v_num] = znormalize(X_train[v_num])
            if ratio < 1.0:
                # X_test[v_num] = Normalize(X_test[v_num])
                X_test[v_num] = znormalize(X_test[v_num])
    
    if ratio < 1.0:
        traindata = DataSet(X_train, view_number, np.array(labels_train))
        testdata = DataSet(X_test, view_number, np.array(labels_test))
        return traindata, testdata, view_number
    else:
        traindata = DataSet(X_train, view_number, np.array(labels_train))
        # testdata = DataSet(X_test, view_number, np.array(labels_test))
        return traindata, None, view_number

def hungarian(cost_mat:np.ndarray):
    """
    cost_mat: cost matrix of shape [num_class, num_cluster]

    ----
    return:
    matches: [num_class, 2] 分配矩阵
    """
    # matches = linear_assignment(cost_mat)
    _, matches = linear_sum_assignment(cost_mat)
    
    return matches

    

class Clustering(object):
    def __init__(self, cls_num:int):
        # self.affinity_mat = affinity_mat
        # self.labels = labels
        self.cls_num = cls_num
        self.clustering_model = SpectralClustering(n_clusters=cls_num, affinity='precomputed')

    def clustering(self, affinity_mat:Union[torch.Tensor, np.ndarray], labels):
        pred_labels = self.clustering_model.fit_predict(affinity_mat)
        # pred_labels = spectral_clustering(affinity=affinity_mat.numpy(), n_clusters=self.cls_num)
        best_matches_pred_labels = self.__best_map(labels, pred_labels)
        return best_matches_pred_labels

    
    def __best_map(self, label:np.ndarray, pred:np.ndarray):
        """
        采用匈牙利算法进行标签与预测簇的匹配
        """
        assert len(label) == len(pred), 'predict and label not match'
        N = len(label)
        clusters = np.unique(pred)
        classes = np.unique(label)
        num_cluster = len(clusters)
        num_class = len(classes)
        G = np.zeros((num_class, num_cluster))
        for i in range(num_class):
            for j in range(num_cluster):
                G[i, j] = np.sum((label == classes[i]) * (pred == clusters[j]))

        # G[num_class, num_cluster]为cost矩阵
        # G[i, j]代表第i类的样本中属于第j个簇的数量
        # 利用匈牙利算法进行最大匹配, 需要用-G转换成最小匹配

        matches = hungarian(-G)
        new_pred = np.zeros_like(pred)
        for i in range(len(clusters)):
            new_pred[pred == clusters[i]] = classes[matches[i]]

        return new_pred

    
    def calc_nmi(self, label:np.ndarray, pred:np.ndarray):
        N = len(label)
        clusters = np.unique(pred)
        classes = np.unique(label)
        num_cluster = len(clusters)
        num_class = len(classes)

        # compute number of points in each class
        cls_cnt = np.array(
            [np.sum(label == cls_id) for cls_id in classes]
        )
        cluster_cnt = np.array(
            [np.sum(pred == cluster_id) for cluster_id in clusters]
        )

        # mutual information
        mi = 0
        A = np.zeros((num_cluster, num_class))
        miarr = np.zeros_like(A)
        avgent = 0

        for i in range(num_cluster):
            index_cluster = pred == clusters[i]
            for j in range(num_class):
                index_class = label == classes[j]
                A[i, j] = np.sum(index_cluster * index_class)
                if A[i, j] != 0:
                    miarr[i, j] = A[i, j] / N * np.log2(N * A[i, j] / (cluster_cnt[i] * cls_cnt[j]))
                    avgent = avgent - (cluster_cnt[i] / N) * (A[i, j] / cluster_cnt[i]) * np.log2(A[i, j] / cluster_cnt[i])
                else:
                    miarr[i, j] = 0.0

                mi += miarr[i, j]
        
        # class_entropy
        cls_ent = np.sum(cls_cnt / N * np.log2(N / cls_cnt))

        # clustering entropy
        clust_ent = np.sum(cluster_cnt / N * np.log2(N / cluster_cnt))

        nmi = 2 * mi / (cls_ent + clust_ent)
        return nmi


    def calc_acc(self, label:np.ndarray, pred:np.ndarray):
        acc = np.sum(label == pred) / len(label)
        return acc
    
    def calc_f(self, label:np.ndarray, pred:np.ndarray):
        assert len(label) == len(pred), 'predict and label not match'
        N = len(label)
        num_true, num_pred, num_i = 0, 0, 0
        for i in range(N):
            label_n = label[i + 1:] == label[i]
            pred_n = pred[i + 1:] == pred[i]
            num_true += np.sum(label_n)
            num_pred += np.sum(pred_n)
            num_i += np.sum(label_n * pred_n)
        
        p, r, f = 1, 1, 1
        if num_pred > 0:
            p = num_i / num_pred
        if num_true > 0:
            r = num_i / num_true
        if p + r == 0:
            f = 0
        else:
            f = 2 * p * r / (p + r)
        
        return f, p, r
  

    def calc_rand_index(self, label:np.ndarray, pred:np.ndarray, adjusted:bool=True):
        if adjusted:
            return adjusted_rand_score(label, pred)
        else:
            assert len(label) == len(pred), 'predict and label not match'
            N = len(label)
            C = contingency_matrix(label, pred) # contingency matrix
            n = np.sum(C)
            nis = np.sum(np.sum(C, axis=1) ** 2) # sum of squares of sums of rows
            njs = np.sum(np.sum(C, axis=0) ** 2) # sum of squares of sums of columns

            t1 = comb(n, 2) # total number of pairs of entities
            t2 = np.sum(C ** 2) # sum over rows & columnns of nij^2
            t3 = 0.5 * (nis + njs)

            # Expected index (for adjustment)
            nc = (n * (n ** 2 + 1) - (n + 1) * (nis + njs)+ 2 * (nis * njs) / n) / \
                (2 * (n - 1))
            A = t1 + t2 - t3 # no. agreements
            D = t3 - t2 # no. disagreements
            if t1 == nc:
                AR = 0
            else:
                AR = (A - nc) / (t1 - nc) # adjusted Rand - Hubert & Arabie 1985
            
            RI = A / t1 # Rand 1971 %Probability of agreement
            MI = D / t1 # Mirkin 1970 %p(disagreement)
            HI = (A - D) / t1 # Hubert 1977 %p(agree)-p(disagree)
            return AR, RI, MI, HI

def RI(label:np.ndarray, pred:np.ndarray, adjusted:bool=True):
    assert len(label) == len(pred), 'predict and label not match'
    N = len(label)
    C = contingency_matrix(label, pred) # contingency matrix
    n = np.sum(C)
    nis = np.sum(np.sum(C, axis=1) ** 2) # sum of squares of sums of rows
    njs = np.sum(np.sum(C, axis=0) ** 2) # sum of squares of sums of columns

    t1 = comb(n, 2) # total number of pairs of entities
    t2 = np.sum(C ** 2) # sum over rows & columnns of nij^2
    t3 = 0.5 * (nis + njs)

    # Expected index (for adjustment)
    nc = (n * (n ** 2 + 1) - (n + 1) * (nis + njs)+ 2 * (nis * njs) / n) / \
        (2 * (n - 1))
    A = t1 + t2 - t3 # no. agreements
    D = t3 - t2 # no. disagreements
    if t1 == nc:
        AR = 0
    else:
        AR = (A - nc) / (t1 - nc) # adjusted Rand - Hubert & Arabie 1985
            
    RI = A / t1 # Rand 1971 %Probability of agreement
    MI = D / t1 # Mirkin 1970 %p(disagreement)
    HI = (A - D) / t1 # Hubert 1977 %p(agree)-p(disagree)
    return AR, RI, MI, HI

if __name__ == "__main__":
    label = np.array([0, 1, 0, 1, 2])
    pred = np.array([0, 1, 0, 0, 2])
    print(RI(label, pred))
            

    
