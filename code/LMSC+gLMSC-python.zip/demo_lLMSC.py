import utils
from lLMSC import LinenarLMSC
import numpy as np
import torch
import scipy.io as sio
import time
import random

seed = 1

random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed(seed)

traindata, testdata, view_number = utils.read_matlab_data('../dataset/ORL_mtv.mat', ratio=1.0, shuffled=False)

l_LMSC_model = LinenarLMSC(
    labels=traindata.labels, 
    class_num=len(np.unique(traindata.labels)), 
    Lambda=1.275,
    K=200,
    max_iter=500,
    cuda_flag=False
)

H_orign = sio.loadmat('./Yale_H_orignal.mat')['H'].astype(np.float64)

t1 =time.time()
Z, H, P, Eh, Er, flag, iteration = l_LMSC_model.train(traindata)
t2 = time.time()
print('converge: {}, total {} iterations, cost {:.2f} s of time'.format(flag, iteration, t2 - t1))
# print(flag, iter)


cluster_model = utils.Clustering(len(np.unique(traindata.labels)))
pred_labels = cluster_model.clustering((torch.abs(Z) + torch.abs(Z.T)) / 2, traindata.labels)

nmi = cluster_model.calc_nmi(traindata.labels, pred_labels)
f, p, r = cluster_model.calc_f(traindata.labels, pred_labels)
acc = cluster_model.calc_acc(traindata.labels, pred_labels)
ar, ri, mi, hi = cluster_model.calc_rand_index(traindata.labels, pred_labels, adjusted=False)

# print(nmi, f, p, r, acc, ri)
print('nmi: {:.3f}, f: {:.3f}, p: {:.3f}, r: {:.3f}, acc: {:.3f}\n AR: {:.3f}, RI: {:.3f}, MI: {:.3f}, HI: {:.3f}'.format(nmi, f, p, r, acc, ar, ri, mi, hi))


pass