from math import inf
import scipy
import scipy.io as sio
from scipy import linalg
from torch.nn.modules.activation import ReLU
from torch.nn.modules.linear import Linear
import utils
import torch
import torch.nn as nn
from torch import cuda
import numpy as np
from typing import Union, List, Dict
from torch import optim
from torch.optim.lr_scheduler import CosineAnnealingWarmRestarts
import math

class GeneralLMSC(object):
    def __init__(
        self, 
        labels:Union[np.ndarray, List[int]], 
        class_num:int,
        Lambda:float,
        K:int,
        miu:float=1e-6,
        rou:float=1.2,
        eps:float=1e-4,
        max_miu:float=1e6,
        thresh:float = 1e-4,
        max_iter:int=100,
        eta1:float=1e-2,
        eta2:float=1e-2,
        gamma:float=0.01,
        cuda_flag:bool=True
    ):
        self._labels = labels
        self.class_num = class_num
        self.Lambda = Lambda
        self.K = K
        self.miu = miu
        self.rou = rou
        self.eps = eps
        self.max_miu = max_miu
        self.thresh = thresh
        self.max_iter = max_iter
        self.cuda_flag = cuda_flag
        self.eta1 = eta1
        self.eta2 = eta2
        self.gamma = gamma # regulariation of network

    @torch.no_grad()
    def __softth(self, F:Union[cuda.FloatTensor, torch.FloatTensor], Lambda:float):
        # temp = F.clone()
        U, S, V = torch.svd(F)
        svp = torch.sum(S > Lambda).item()
        # svp = 1 if svp == 0 else svp
        diags = torch.clamp(S - Lambda, min=0.0)
        result = torch.mm(
            torch.mm(U[:, :svp], torch.diag(diags[:svp])),
            V[:, :svp].T
        )
        return result

    @torch.no_grad()
    def __update_networks(
        self, 
        X:Union[utils.DataSet, dict], 
        D:Union[List[int], np.ndarray],
        alpha
    ):
        for i in range(len(D)):
            converge_flag = False
            iter = 0
            I = torch.eye(self.W1s[0].shape[0])
            if self.cuda_flag:
                I = I.cuda()
            while(not converge_flag and iter < self.max_iter):
                M = torch.tanh(torch.mm(self.W1s[i], self.H))
                self.W2s[i] = torch.mm(
                    torch.mm(X[i], M.T), 
                    torch.inverse(
                        torch.mm(M, M.T) + (self.gamma / alpha[i] + 1e-6) * I
                    )
                    # X{v} * M{v}' / (M{v} * M{v}' + gamma / alpha{v} * I + I * 1e-6)
                )
                grad_W1 = alpha[i] * torch.mm(
                    (1 - M * M) * \
                    (
                        torch.mm(torch.mm(self.W2s[i].T, self.W2s[i]), M) - \
                            torch.mm(self.W2s[i].T, X[i])
                    ), self.H.T
                ) + self.gamma * self.W1s[i]
                # alpha{v} * ((1 - M{v} .* M{v}) .* (W2{v}' * W2{v} * M{v} - W2{v}' * X{v})) * H' + gamma * W1{v}
                self.W1s[i] = self.W1s[i] - self.eta1 * grad_W1

                converge_norm = torch.norm(X[i] - torch.mm(self.W2s[i], torch.tanh(torch.mm(self.W1s[i], self.H))), p='fro')
                if converge_norm < self.thresh:
                    converge_flag = True
                iter += 1
    
    @torch.no_grad()
    def __update_H(
        self, 
        X:Union[utils.DataSet, dict], 
        V:int,
        alpha
    ):
        N = self.Z.shape[0]
        converge_flag = False
        iter = 0
        I = torch.eye(N)
        if self.cuda_flag:
            I = I.cuda()

        while(not converge_flag and iter < self.max_iter):
            old_fv = torch.norm(self.H - torch.mm(self.H, self.Z), p='fro')
            for i in range(V):
                old_fv += alpha[i] * torch.norm(X[i] - torch.mm(self.W2s[i], torch.tanh(torch.mm(self.W1s[i], self.H))), p='fro')
  
            TM = 0
            for i in range(V):
                M = torch.tanh(torch.mm(self.W1s[i], self.H))
                TM += alpha[i] * torch.mm(
                    self.W1s[i].T,
                    (1 - M * M) * \
                        (torch.mm(torch.mm(self.W2s[i].T, self.W2s[i]), M) - torch.mm(self.W2s[i].T, X[i]))
                )
            grad_H = TM + torch.mm(
                self.H, 
                I - self.Z - self.Z.T + torch.mm(self.Z, self.Z.T)
            )
            self.H = self.H - self.eta2 * grad_H

            new_fv = torch.norm(self.H - torch.mm(self.H, self.Z), p='fro')
            for i in range(V):
                new_fv += alpha[i] * torch.norm(X[i] - torch.mm(self.W2s[i], torch.tanh(torch.mm(self.W1s[i], self.H))), p='fro')
                    

            if old_fv < new_fv:
                converge_flag = True
            iter += 1


    @torch.no_grad()
    def __update_Z(self, N):
        I = torch.eye(N, N)
        if self.cuda_flag:
            I = I.cuda()
        self.Z = torch.mm(
            torch.inverse(torch.mm(self.H.T, self.H) + self.miu * I),
            self.miu * self.J + self.Y + torch.mm(self.H.T, self.H)
        )


    @torch.no_grad()
    def __train_a_epoch(self, X:Union[utils.DataSet, dict], N, D, alpha):
        self.__update_networks(X, D, alpha)
        cuda.empty_cache()
        self.__update_H(X, len(D), alpha)
        cuda.empty_cache()
        
        # update Z
        self.__update_Z(N)
        cuda.empty_cache()

        # update J
        I = torch.eye(N, N)
        if self.cuda_flag:
            I = I.cuda()
        self.J = self.__softth(
            (self.Z - self.Y / self.miu) + I * 1e-8,
            self.Lambda / self.miu
        )
        
        self.Y = self.Y + self.miu * (self.J - self.Z)
        cuda.empty_cache()

    @torch.no_grad()
    def __is_converged(self):
        a = torch.norm(self.J - self.Z, inf)
        if a < self.thresh:
            return True, a
        else:
            return False, a

    @torch.no_grad()
    def train(
        self, 
        X:Union[Dict[int, Union[np.ndarray, torch.Tensor]], utils.DataSet],
        H_orign:Union[np.ndarray, torch.Tensor]=None
    ):
        if isinstance(X, dict):
            V = len(X)
            D = [x.shape[1] for x in X.values()]
            # M = torch.cat([torch.from_numpy(x) for x in X.values()], dim=1).double().T
            X = {int(key):torch.tensor(value).double().T for key, value in X.items()}
            if self.cuda_flag:
                X = {key:value.cuda() for key, value in X.items()}
        elif isinstance(X, utils.DataSet):
            V = X.view_cnt
            D = [x.shape[1] for x in X.data.values()]
            X = X = {int(key):torch.tensor(value).double().T for key, value in X.data.items()}
            if self.cuda_flag:
                X = {key:value.cuda() for key, value in X.items()}
            # M = torch.cat([torch.from_numpy(x) for x in X.data.values()], dim=1).double().T
        else:
            V = X.shape[1]
            D = [x.shape[0] for x in X]
            # M = torch.FloatTensor(X).double()

        try:
            N = X[0].shape[1]
        except Exception:
            N = X[1].shape[1]
        
        # 初始化参数
        alpha = torch.ones(V).double() / V
        self.Z = torch.zeros(N, N).double()
        self.J = torch.zeros(N, N).double()
        self.Y = torch.zeros(N, N).double()
        if H_orign is None:
            self.H = torch.abs(torch.rand(self.K, N).double()) / 10.0
        else:
            self.H = torch.tensor(H_orign).double() / 10.0
        # self.W1s = [torch.rand(self.K, self.K).double() for _ in range(V)]
        self.W1s = [torch.from_numpy(utils.matlab_normalize(np.random.rand(self.K, self.K).astype(np.float64))) for _ in range(V)]
        # self.W2s = [torch.rand(D[i], self.K).double() for i in range(V)]
        self.W2s = [torch.zeros(D[i], self.K).double() for i in range(V)]

        if self.cuda_flag:
            alpha = alpha.cuda()
            self.Z = self.Z.cuda()
            self.J = self.J.cuda()
            self.Y = self.Y.cuda()
            self.H = self.H.cuda()
            self.W1s = [w.cuda() for w in self.W1s]
            self.W2s = [w.cuda() for w in self.W2s]
        
        converge_flag = False
        iter = 0

        while ((not converge_flag) and iter < self.max_iter):
            self.__train_a_epoch(X, N, D, alpha)
            self.miu = np.min([self.max_miu, self.rou * self.miu])
            converge_flag, conv = self.__is_converged()
            iter += 1

        return self.Z.cpu(), self.H.cpu(), converge_flag, iter, conv

        
class GeneralLMSCModel(nn.Module):
    def __init__(
        self, 
        class_num:int,
        Xdim:Union[List[int], np.ndarray, torch.LongTensor],
        alpha:Union[List[float], np.ndarray, torch.FloatTensor], 
        N:int,
        Lambda:float,
        K:int,
        dropout=0.5,
        H_orign:Union[torch.FloatTensor, np.ndarray]=None,
        miu:float=1e-6,
        max_miu:float=1e6,
        converge_thresh:float=1e-4,
        gamma:float=0.01,
        cuda_flag:bool=True,
        grad_Z:bool=False
    ):
        super(GeneralLMSCModel, self).__init__()
        self.class_num = class_num
        self.Lambda = Lambda
        self.K = K
        self.N = N
        self.miu = miu
        self.max_miu = max_miu
        self.gamma = gamma # regulariation of network
        self.converge_thresh = converge_thresh
        self.cuda_flag = cuda_flag

        self.Xdim = Xdim
        self.V = len(Xdim)
        self.alpha = torch.tensor(alpha).double()
        
        # 初始化参数, Z, J, Y有解析解的优化, W1s, W2s(两层全连接层)和H利用网络梯度优化
          
        if H_orign is None:
            self.H = torch.abs(torch.rand(self.K, self.N).double()) / 10.0
        else:
            self.H = torch.tensor(H_orign).double() / 10.0
        
        if grad_Z:
            self.Z = torch.rand(self.N, self.N).double() * (torch.max(self.H).item() - torch.min(self.H).item())
        else:
            self.Z = torch.zeros(self.N, self.N).double()
        
        self.J = torch.zeros(self.N, self.N).double()
        self.Y = torch.zeros(self.N, self.N).double()
        
        hidden = [math.ceil(2 * np.sqrt(self.K + self.Xdim[i]))for i in range(self.V)]
        
        self.networks = [
            nn.Sequential(
                nn.Linear(self.K, hidden[i]),
                nn.Tanh(),
                nn.Linear(hidden[i], self.Xdim[i])
                # nn.Linear(self.K, self.Xdim[i])
            ).double() for i in range(self.V)
            # nn.Sequential(
            #     nn.Linear(self.K, self.K),
            #     nn.Tanh(),
            #     nn.Linear(self.K, hidden[i]),
            #     nn.Tanh(),
            #     nn.Linear(hidden[i], self.Xdim[i])
            #     # nn.Linear(self.K, self.Xdim[i])
            # ).double() for i in range(self.V)
        ]
        # for i in range(self.V):
        #     nn.init.xavier_uniform_(self.networks[i].parameters())
        # for i in range(self.V):
        #     self.networks[i][-1].weight.data.zero_()
        #     self.networks[i][0].weight.data.uniform_(0, torch.max(torch.abs(self.networks[i][0].weight.data)))

        if self.cuda_flag:
            self.cuda()
        self.H.requires_grad_(True)
        self.grad_Z = grad_Z
        if self.grad_Z:
            self.Z.requires_grad_(True)

    def cuda(self):
        self.Z = self.Z.cuda()
        self.J = self.J.cuda()
        self.Y = self.Y.cuda()
        self.H = self.H.cuda()
        self.networks = [n.cuda() for n in self.networks]
        return self

    def forward(self, X:Union[Dict[int, Union[np.ndarray, torch.Tensor]], utils.DataSet]):
        W_losses = torch.stack([
            0.5 * torch.norm(X[i] - self.networks[i].forward(self.H.T).T, p='fro') ** 2
             for i in range(self.V)
        ])

        if self.grad_Z:
            loss = 0.5 * torch.norm(self.H - torch.mm(self.H, self.Z), p='fro') ** 2 + \
                torch.sum(self.alpha * W_losses) + self.Lambda * torch.norm(self.Z, p='nuc')
        else:
            loss = 0.5 * torch.norm(self.H - torch.mm(self.H, self.Z), p='fro') ** 2 + \
                torch.sum(self.alpha * W_losses)
        
        return loss

    def Wforward(self, X:Dict[int, torch.Tensor]):
        W_losses = torch.stack([
            0.5 * torch.norm(X[i] - self.networks[i].forward(self.H.T).T, p='fro') ** 2
             for i in range(self.V)
        ])
        W_loss = torch.sum(self.alpha * W_losses)

        return W_loss
    
    def Hforward(self, X:Dict[int, torch.Tensor]):
        W_losses = torch.stack([
            0.5 * torch.norm(X[i] - self.networks[i].forward(self.H.T).T, p='fro') ** 2
             for i in range(self.V)
        ])

        H_loss = 0.5 * torch.norm(self.H - torch.mm(self.H, self.Z), p='fro') ** 2 + \
            torch.sum(self.alpha * W_losses)
        
        return H_loss
    
    def Zforward(self):
        Z_loss = 0.5 * torch.norm(self.H - torch.mm(self.H, self.Z), p='fro') ** 2 + \
            self.Lambda * torch.norm(self.Z, p='nuc')
        
        return Z_loss
    
    @torch.no_grad()
    def softth(self, F:Union[torch.cuda.FloatTensor, torch.FloatTensor], Lambda:float):
        # temp = F.clone()
        U, S, V = torch.svd(F)
        svp = torch.sum(S > Lambda).item()
        # svp = 1 if svp == 0 else svp
        diags = torch.clamp(S - Lambda, min=0.0)
        result = torch.mm(
            torch.mm(U[:, :svp], torch.diag(diags[:svp])),
            V[:, :svp].T
        )
        return result
    

class GeneralLMSCTrainer(object):
    def __init__(
        self, 
        X:utils.DataSet,
        Lambda:float,
        K:int,
        lrW:float, lrH:float, lrZ:float,
        weight_decay=1e-5,
        max_iter:int=100,
        converge_thresh:float=5e-3,
        alpha:Union[List[float], np.ndarray, torch.FloatTensor]=None, 
        H_orign:Union[torch.FloatTensor, np.ndarray]=None,
        miu:float=1e-6,
        max_miu:float=1e6,
        gamma:float=0.001,
        cuda_flag:bool=True,
        grad_Z:bool=False,
        separate_updated:bool=False
    ):
        self.cuda_flag = cuda_flag
        V = X.view_cnt
        Xdim = [x.shape[1] for x in X.data.values()]
        class_num = len(np.unique(X.labels))
        # self.X = X 
        self.converge_thresh = converge_thresh
        self.max_iter = max_iter
        self.grad_Z = grad_Z
        if separate_updated:
            assert grad_Z, 'separate_updated requires the grad of Z'
        self.separate_updated = separate_updated

        try:
            self.N = X.data['0'].shape[0]
        except Exception:
            self.N = X.data['1'].shape[0]
        
        if alpha is None:
            alpha = torch.ones(V).double() / V
        else:
            alpha = torch.tensor(alpha).double()
        
        if self.cuda_flag:
            alpha = alpha.cuda()
        
        if isinstance(X, utils.DataSet):
            X = X = {int(key):torch.tensor(value).double().T for key, value in X.data.items()}
            if self.cuda_flag:
                X = {key:value.cuda() for key, value in X.items()}
        elif isinstance(X, dict):
            X = {int(key):torch.tensor(value).double().T for key, value in X.items()}
            if self.cuda_flag:
                X = {key:value.cuda() for key, value in X.items()}
            
        self.X = X

        self.model = GeneralLMSCModel(
            class_num=class_num,
            Xdim = Xdim,
            alpha=alpha,
            N=self.N,
            Lambda=Lambda,
            K=K,
            H_orign=H_orign,
            miu=miu,
            max_miu=max_miu,
            converge_thresh=converge_thresh,
            gamma=gamma,
            cuda_flag=cuda_flag,
            grad_Z=grad_Z
        )
    
        self.optimW = optim.Adam(
            [{'params':network.parameters()} for network in self.model.networks],
            lr=lrW,
            amsgrad=True, weight_decay=gamma # L2正则项
        )
        self.optimH = optim.Adam(
            [self.model.H], lr=lrH,
            amsgrad=True, weight_decay=weight_decay
        )
        self.optimZ = optim.Adam(
            [self.model.Z], lr=lrZ,
            amsgrad=True, weight_decay=weight_decay
        )

        if not self.grad_Z:
            self.optim = optim.Adam(
                [{'params':network.parameters()} for network in self.model.networks] + [{'params':self.model.H}],
                lr=lrW,
                amsgrad=True, weight_decay=gamma # L2正则项
            )
        else:
            self.optim = optim.Adam(
                [{'params':network.parameters()} for network in self.model.networks] + [{'params':self.model.H}] + [{'params':self.model.Z}],
                lr=lrW,
                amsgrad=True, weight_decay=gamma # L2正则项
            )

        self.scheduleW = CosineAnnealingWarmRestarts(self.optimW, T_0=10, T_mult=2, eta_min=5e-4)
        self.scheduleH = CosineAnnealingWarmRestarts(self.optimH, T_0=10, T_mult=2, eta_min=1e-4)
        self.scheduleZ = CosineAnnealingWarmRestarts(self.optimZ, T_0=10, T_mult=2, eta_min=1e-4)
        self.schedule = CosineAnnealingWarmRestarts(self.optim, T_0=10, T_mult=2, eta_min=1e-4)
    
    
    def train_a_epoch(self):
        self.model.train()
        if not self.separate_updated:
            if not self.grad_Z:
                i = 0
                while True and i < self.max_iter:
                    loss = self.model.forward(self.X)
                    if loss < self.converge_thresh:
                        break
                    self.optim.zero_grad()
                    loss.backward()
                    self.optim.step()
                    i += 1

                with torch.no_grad():
                    # update Z
                    I = torch.eye(self.N, self.N)
                    if self.cuda_flag:
                        I = I.cuda()
                    self.model.Z = torch.mm(
                        torch.inverse(torch.mm(self.model.H.T, self.model.H) + self.model.miu * I),
                        self.model.miu * self.model.J + self.model.Y + torch.mm(self.model.H.T, self.model.H)
                    )
                    # update J
                    self.model.J = self.model.softth(
                        (self.model.Z - self.model.Y / self.model.miu) + I * 1e-8,
                        self.model.Lambda / self.model.miu
                    )
                    
                    # update Y
                    self.model.Y = self.model.Y + self.model.miu * (self.model.J - self.model.Z)

                    conv = torch.norm(self.model.J - self.model.Z, inf)

                self.scheduleW.step()
                self.scheduleH.step()
                # return conv.cpu().item(), W_loss.detach().item(), H_loss.detach().item()
                return conv.cpu().item(), loss.detach().item()

            else:
                for _ in range(self.max_iter):
                    loss = self.model.forward(self.X)
                    self.optim.zero_grad()
                    loss.backward()
                    self.optim.step()
                self.schedule.step()
                return 1.0, 1.0, loss.detach().item()
        else:
            for _ in range(self.max_iter):
                W_loss = self.model.Wforward(self.X)
                self.optimW.zero_grad()
                W_loss.backward()
                self.optimW.step()
            for _ in range(self.max_iter):
                H_loss = self.model.Hforward(self.X)
                self.optimH.zero_grad()
                H_loss.backward()
                self.optimH.step()
            for _ in range(self.max_iter):
                Z_loss = self.model.Zforward()
                self.optimZ.zero_grad()
                Z_loss.backward()
                self.optimZ.step()
            self.scheduleW.step()
            self.scheduleH.step()
            self.scheduleZ.step()

            return W_loss.detach().item(), H_loss.detach().item(), Z_loss.detach().item()     


    def get_affine_mat(self):
        self.model.eval()
        return self.model.Z.detach().cpu(), self.model.H.detach().cpu()

    def save(self, path):
        torch.save(self.model.state_dict(), path)

    def load(self, path):
        self.model.load_state_dict(torch.load(path))
        

    
        
        
        
        
        
        
        