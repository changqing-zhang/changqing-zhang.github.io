from math import inf
import scipy
import scipy.io as sio
from scipy import linalg
import utils
import torch
from torch import cuda
import numpy as np
from typing import Union, List, Dict

class LinenarLMSC(object):
    def __init__(
        self, 
        labels:Union[np.ndarray, List[int]], 
        class_num:int,
        Lambda:float,
        K:int,
        miu:float=1e-6,
        rou:float=1.5,
        eps:float=1e-4,
        max_miu:float=1e6,
        thresh:float = 1e-4,
        max_iter:int=100,
        cuda_flag:bool=True
    ):
        self._labels = labels
        self.class_num = class_num
        self.Lambda = Lambda
        self.K = K
        self.miu = miu
        self.rou = rou
        self.eps = eps
        self.max_miu = max_miu
        self.thresh = thresh
        self.max_iter = max_iter
        self.cuda_flag = cuda_flag

    @torch.no_grad()
    def __update_P(self, M):
        Q = ((1 / self.miu) * self.Y1 + M - self.Eh).T
        W = torch.mm(self.H, Q)
        U, _, V = torch.svd(W)
        # temp = torch.mm(torch.mm(U, torch.diag(S)), V.T) - W
        P = torch.mm(V, U.T)
        cuda.empty_cache()
        return P

    @torch.no_grad()
    def __update_P2(self, M):
        Q = ((1 / self.miu) * self.Y1 + M - self.Eh).T
        W = torch.mm(self.H, Q)
        U, _, V = np.linalg.svd(W.cpu().numpy(), full_matrices=False)
        if self.cuda_flag:
            U = torch.from_numpy(U).cuda()
            V = torch.from_numpy(V).cuda()
        else:
            U = torch.from_numpy(U)
            V = torch.from_numpy(V)
        P = torch.mm(U, V).T
        cuda.empty_cache()
        return P
    
    @torch.no_grad()
    def __update_H(
        self, 
        A:Union[cuda.FloatTensor, torch.FloatTensor], 
        B:Union[cuda.FloatTensor, torch.FloatTensor], 
        C:Union[cuda.FloatTensor, torch.FloatTensor]
    ):
        a = A.cpu().numpy()
        b = B.cpu().numpy()
        c = C.cpu().numpy()
        h = linalg.solve_sylvester(a, b, c)
        H = torch.from_numpy(h)
        if self.cuda_flag:
            H = H.cuda()
        return H

    @torch.no_grad()
    def __softth(self, F:Union[cuda.FloatTensor, torch.FloatTensor], Lambda:float):
        # temp = F.clone()
        U, S, V = torch.svd(F)
        svp = torch.sum(S > Lambda).item()
        # svp = 1 if svp == 0 else svp
        diags = torch.clamp(S - Lambda, min=0.0)
        result = torch.mm(
            torch.mm(U[:, :svp], torch.diag(diags[:svp])),
            V[:, :svp].T
        )
        return result
    
    @torch.no_grad()
    def __solve_l1l2(self, W:Union[cuda.FloatTensor, torch.FloatTensor], Lambda:float):
        result = W.clone()
        nw = torch.norm(result, dim=0, p=2)
        diag = torch.clamp(torch.diag((nw - Lambda) / nw), min=0)
        result = torch.mm(result, diag)

        return result
    
    @torch.no_grad()
    def __train_a_epoch(self, M, N, SD):
        # update P
        self.P = self.__update_P(M)
        # update H
        A = self.miu * torch.mm(self.P.T, self.P)
        if self.cuda_flag:
            B = self.miu * (torch.mm(self.Z, self.Z.T) - self.Z - self.Z.T + torch.eye(N).cuda()) + \
                torch.eye(N).cuda() * 1e-6
        else:
            B = self.miu * (torch.mm(self.Z, self.Z.T) - self.Z - self.Z.T + torch.eye(N)) + \
                torch.eye(N) * 1e-6
        
        C = torch.mm(self.P.T, self.Y1) + torch.mm(self.Y2, self.Z.T) - self.Y2 + \
            self.miu * (torch.mm(self.P.T, M) + self.Er - torch.mm(self.P.T, self.Eh) - torch.mm(self.Er, self.Z.T))
        
        self.H = self.__update_H(A, B, C)
        cuda.empty_cache()
        # update J

        if self.cuda_flag:
            self.J = self.__softth(
                (self.Z - self.Y3 / self.miu) + torch.eye(N).cuda() * 1e-8,
                self.Lambda / self.miu
            )
        else:
            self.J = self.__softth(
                (self.Z - self.Y3 / self.miu) + torch.eye(N) * 1e-8,
                self.Lambda / self.miu
            )
        cuda.empty_cache()
        # update Z
        if self.cuda_flag:
            self.Z = torch.mm(
                torch.inverse(torch.mm(self.H.T, self.H) + torch.eye(N).cuda()),
                ((self.J + torch.mm(self.H.T, self.H) - torch.mm(self.H.T, self.Er)) + (self.Y3 + torch.mm(self.H.T, self.Y2)) / self.miu)
            )
        else:
            self.Z = torch.mm(
                torch.inverse(torch.mm(self.H.T, self.H) + torch.eye(N)),
                ((self.J + torch.mm(self.H.T, self.H) - torch.mm(self.H.T, self.Er)) + (self.Y3 + torch.mm(self.H.T, self.Y2)) / self.miu)
            )
        cuda.empty_cache()
        # update E

        G = torch.cat([
            M - torch.mm(self.P, self.H) + self.Y1 / self.miu,
            self.H - torch.mm(self.H, self.Z) + self.Y2 / self.miu
        ], dim=0)
        self.E = self.__solve_l1l2(G, 1 / self.miu)
        cuda.empty_cache()
        self.Eh = self.E[:SD, :]
        self.Er = self.E[SD:, :]

        # update multipliers
        self.Y1 = self.Y1 + self.miu * (M - torch.mm(self.P, self.H) - self.Eh)
        self.Y2 = self.Y2 + self.miu * (self.H - torch.mm(self.H, self.Z) - self.Er)
        self.Y3 = self.Y3 + self.miu * (self.J - self.Z)
        cuda.empty_cache()

    @torch.no_grad()
    def __is_converged(self, M):
        a = torch.norm(M - torch.mm(self.P, self.H) - self.Eh, inf)
        b = torch.norm(self.H - torch.mm(self.H, self.Z) - self.Er, inf)
        c = torch.norm(self.J - self.Z, inf)
        if a < self.thresh and b < self.thresh and c < self.thresh:
            return True, a, b, c
        else:
            return False, a, b, c
        
    @torch.no_grad()
    def train(
        self, 
        X:Union[Dict[int, Union[np.ndarray, torch.Tensor]], utils.DataSet],
        H_orign:Union[np.ndarray, torch.Tensor]=None
    ):
        if isinstance(X, dict):
            V = len(X)
            M = torch.cat([torch.from_numpy(x) for x in X.values()], dim=1).double().T
        elif isinstance(X, utils.DataSet):
            V = X.view_cnt
            M = torch.cat([torch.from_numpy(x) for x in X.data.values()], dim=1).double().T
        else:
            V = X.shape[1]
            M = torch.FloatTensor(X).double()

        try:
            N = M.shape[1]
        except Exception:
            N = M.shape[1]
        
                
        SD = M.shape[0]
        
        # 初始化参数
        self.P = torch.zeros(SD, self.K).double()
        if H_orign is None:
            self.H = torch.abs(torch.rand(self.K, N).double())
        else:
            self.H = torch.tensor(H_orign).double()
        
        self.Z = torch.zeros(N, N).double()
        self.J = torch.zeros(N, N).double()
        self.Eh = torch.zeros(SD, N).double()
        self.Er = torch.zeros(self.K, N).double()
        self.E = torch.cat([self.Eh, self.Er], dim=0)
        self.Y1 = torch.zeros(SD, N).double()
        self.Y2 = torch.zeros(self.K, N).double()
        self.Y3 = torch.zeros(N, N).double()
        if self.cuda_flag:
            M = M.cuda()
            self.P = self.P.cuda()
            self.H = self.H.cuda()
            self.Z = self.Z.cuda()
            self.J = self.J.cuda()
            self.E = self.E.cuda()
            self.Eh = self.Eh.cuda()
            self.Er = self.Er.cuda()
            self.Y1 = self.Y1.cuda()
            self.Y2 = self.Y2.cuda()
            self.Y3 = self.Y3.cuda()

        converge_flag = False
        iter = 0

        while ((not converge_flag) and iter < self.max_iter):
            self.__train_a_epoch(M, N, SD)
            self.miu = np.min([self.max_miu, self.rou * self.miu])
            converge_flag, a, b, c = self.__is_converged(M)
            iter += 1


        return self.Z.cpu(), self.H.cpu(), self.P.cpu(), self.Eh.cpu(), self.Er.cpu(), converge_flag, iter

        

        
        